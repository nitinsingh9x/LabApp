# UIRoutin in angularjs with abstract state
